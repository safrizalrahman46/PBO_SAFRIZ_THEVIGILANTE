

public class DemoPersegi {
    public static void main(String[] args) {
        panjanPersegipanjang panjanPersegipanjang = new panjanPersegipanjang(5, 10);
        panjanPersegipanjang.displayInfo();
        System.out.println("Area: " + panjanPersegipanjang.getArea());
        System.out.println("Circumference: " + panjanPersegipanjang.getCircumference());
    }
}
