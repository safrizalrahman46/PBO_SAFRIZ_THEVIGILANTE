
public class barangsDemo {
    public static void main(String[] args) {
        barangsilegals barang1 = new barangsilegals();
        barang1.kodebarangs = "jamuan mahal";
        barang1.nama = "Jamuan Kartanegara";
        barang1.hargakotor = 35.000;
        barang1.diskonnatalan = 2.500;
        barang1.diskonnyepi = 3.000;

        barang1.displayInfo();
    }
}
