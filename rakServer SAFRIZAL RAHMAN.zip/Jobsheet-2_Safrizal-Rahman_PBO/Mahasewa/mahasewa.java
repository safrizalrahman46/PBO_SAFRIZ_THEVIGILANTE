import java.util.Random;

public class mahasewa {
    mahasiswa mhs = new mahasiswa();
    mahasiswa ani = new mahasiswa();
    mahasiswa mahasiswa = new mahasiswa();
    Random r = new Random();
    // Pegawai pegawai1 = new Pegawai();

}
