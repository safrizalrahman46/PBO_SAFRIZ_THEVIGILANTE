// package Mahasewa;

public class mahasiswademo {
    public static void main(String[] args) {
        mahasiswa mahasewasafrizal = new mahasiswa();
        mahasewasafrizal.nim = "082213286139";
        mahasewasafrizal.nama = "Safrizal Rahman";
        mahasewasafrizal.alamat = "Batu, Jawa Timur";
        mahasewasafrizal.kelas = "2G";

        //ini gimana caranya
        System.out.println("QUOTE OF THE DAY APA LOO");

        mahasiswa mahasewasafrizal2= new mahasiswa();
        mahasewasafrizal2.nim = "0822132861772";
        mahasewasafrizal2.nama = "Arkan";
        mahasewasafrizal2.alamat = "Malang, Jawa Timur";
        mahasewasafrizal2.kelas = "2G";


        // mahasewasafrizal.displayBiodata();
        // mahasewasafrizal2.displayBiodata();
        // println();
        mahasewasafrizal.displayBiodata();
        mahasewasafrizal.println();
        mahasewasafrizal2.displayBiodata();
        mahasewasafrizal2.println();
    
    }
}