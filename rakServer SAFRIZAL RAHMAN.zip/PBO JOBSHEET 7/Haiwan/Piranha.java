package Haiwan;

public class Piranha extends Ikan {
    // @Override
    public void swim() {
        System.out.println("Piranha bisa makan daging");
    }
}