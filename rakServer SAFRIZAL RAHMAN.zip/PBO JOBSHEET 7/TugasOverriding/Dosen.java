package TugasOverriding;

public class Dosen extends Manusia {
    // @Override
    public void makan() {
        System.out.println("Dosen makan di kantin universitas.");
    }

    public void lembur() {
        System.out.println("Dosen sedang lembur menyiapkan materi.");
    }
}