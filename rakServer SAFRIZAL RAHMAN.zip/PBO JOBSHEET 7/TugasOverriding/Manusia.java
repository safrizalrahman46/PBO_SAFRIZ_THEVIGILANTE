package TugasOverriding;

public class Manusia {
    public void bernafas() {
        System.out.println("Manusia bisa bernafas.");
    }

    public void makan() {
        System.out.println("Manusia makan makanan.");
    }
}