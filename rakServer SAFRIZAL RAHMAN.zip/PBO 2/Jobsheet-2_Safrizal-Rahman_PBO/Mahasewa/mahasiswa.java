

// /**
//  * mahasiswa
//  */
// public class mahasiswa {

//     public string nim;
//     public string nama;
//     public string alamat;
//     public string nomorBBM;
//     // public string nim;

// }

public class mahasiswa {
    public String nim;
    public String nama;
    public String alamat;
    public String kelas;

    public void displayBiodata() {
        System.out.println("NIM: " + nim);
        System.out.println("Nama: " + nama);
        System.out.println("Alamat: " + alamat);
        System.out.println("Kelas: " + kelas);
    }
}


