public class DemoUserTakterkendalikan {
    public static void main(String[] args) {
        // Create a User object with required attributes
        Users user1 = new Users("annisa.nadya", "Annisa Nadya", "annisa.nadya@gmail.com");

        // Print user information
        user1.cetakInfo();
    } 
}
